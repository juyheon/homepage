import Footer from '../components/Footer';
import Header from '../components/Header';


import { useEffect } from 'react';

function Program() {
    return (
        <>
            <Header />
                <div>
                    <h1>홈페이지</h1>
                </div>
            <Footer />
        </>
    );
}

export default Program;