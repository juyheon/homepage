import Footer from '../components/Footer';
import Header from '../components/Header';


import { useEffect } from 'react';

function Shop() {
    return (
        <>
            <Header />
                <div>
                    <h1>숍</h1>
                </div>
            <Footer />
        </>
    );
}

export default Shop;