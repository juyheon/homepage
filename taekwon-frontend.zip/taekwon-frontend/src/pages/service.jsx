import Footer from '../components/Footer';
import Header from '../components/Header';


import { useEffect } from 'react';

function Service() {
    return (
        <>
            <Header />
                <div>
                    <h1>서비스</h1>
                </div>
            <Footer />
        </>
    );
}

export default Service;