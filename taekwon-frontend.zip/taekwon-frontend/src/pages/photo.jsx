import Footer from '../components/Footer';
import Header from '../components/Header';


import { useEffect } from 'react';

function Photo() {
    return (
        <>
            <Header />
                <div>
                    <h1>포토토</h1>
                </div>
            <Footer />
        </>
    );
}

export default Photo;